import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import multer from "multer";
import fs from "fs/promises";
import crypto from "crypto";
import nodemailer from "nodemailer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const loadEnvFile = async () => {
  try {
    const envPath = path.join(__dirname, ".env");
    const raw = await fs.readFile(envPath, "utf8");
    for (const line of raw.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIndex = trimmed.indexOf("=");
      if (eqIndex === -1) continue;
      const key = trimmed.slice(0, eqIndex).trim();
      if (!key || process.env[key]) continue;
      let value = trimmed.slice(eqIndex + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      process.env[key] = value;
    }
  } catch (err) {
    if (err?.code !== "ENOENT") {
      console.error("Failed to load .env file", err);
    }
  }
};

await loadEnvFile();

const app = express();
const PORT = process.env.PORT || 3001;
const IS_PRODUCTION = process.env.NODE_ENV === "production";
const resolveAppPath = (value, fallback) => {
  const selected = String(value || fallback || "").trim();
  return path.isAbsolute(selected) ? selected : path.join(__dirname, selected);
};
const imageFileFilter = (req, file, cb) => {
  const allowedMime = /^image\/(png|jpe?g|webp|avif)$/i.test(file.mimetype || "");
  const allowedExt = /\.(png|jpe?g|webp|avif)$/i.test(file.originalname || "");
  if (!allowedMime || !allowedExt) {
    return cb(new Error("Only PNG, JPG, WEBP, and AVIF images are allowed"));
  }
  return cb(null, true);
};
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 6 * 1024 * 1024 },
  fileFilter: imageFileFilter
});
const uploadDir = resolveAppPath(process.env.UPLOAD_DIR, path.join("public", "uploads"));
const uploadImage = multer({
  storage: multer.diskStorage({
    destination: async (req, file, cb) => {
      try {
        await fs.mkdir(uploadDir, { recursive: true });
        cb(null, uploadDir);
      } catch (err) {
        cb(err, uploadDir);
      }
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      const safeExt = ext && ext.length <= 6 ? ext : ".jpg";
      cb(null, `${crypto.randomUUID()}${safeExt}`);
    }
  }),
  limits: { fileSize: 6 * 1024 * 1024 },
  fileFilter: imageFileFilter
});
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || crypto.randomBytes(16).toString("hex");
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "";
const OTP_SECRET = process.env.OTP_SECRET || crypto.randomBytes(32).toString("hex");
const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_COOLDOWN_MS = 60 * 1000;
const ADMIN_TOKEN_TTL_MS = 24 * 60 * 60 * 1000;
const DATA_DIR = resolveAppPath(process.env.DATA_DIR, "data");
const DATA_FILE = path.join(DATA_DIR, "submissions.json");
const CONTENT_FILE = path.join(DATA_DIR, "content.json");
const PUBLIC_CONTENT_FILE = path.join(__dirname, "public", "content.json");
const ADMIN_CONFIG_FILE = path.join(DATA_DIR, "admin.json");
const MEMBERS_FILE = path.join(DATA_DIR, "members.json");
const revokedAdminTokens = new Set();
const memberTokens = new Map();
const otpStore = new Map();

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || "";

app.use(express.json({ limit: "32mb" }));
app.disable("x-powered-by");
if (IS_PRODUCTION) {
  app.set("trust proxy", 1);
}
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  if (IS_PRODUCTION && req.secure) {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }
  if (req.path.startsWith("/api/")) {
    res.setHeader("Cache-Control", "no-store");
  }
  next();
});
if (IS_PRODUCTION && String(process.env.FORCE_HTTPS || "").toLowerCase() === "true") {
  app.use((req, res, next) => {
    if (req.secure || req.path === "/api/health") return next();
    return res.redirect(301, `https://${req.headers.host}${req.originalUrl}`);
  });
}
const cleanPageRoutes = new Map([
  ["/index.html", "/"],
  ["/gallery.html", "/gallery"],
  ["/shop.html", "/shop"],
  ["/machines.html", "/machines"],
  ["/coaches.html", "/coaches"],
  ["/spa.html", "/spa"],
  ["/membership.html", "/membership"],
  ["/dashboard.html", "/dashboard"],
  ["/tour.html", "/tour"],
  ["/admin.html", "/admin"]
]);
app.use((req, res, next) => {
  const cleanPath = cleanPageRoutes.get(req.path);
  if (!cleanPath) return next();
  const queryIndex = req.originalUrl.indexOf("?");
  const query = queryIndex >= 0 ? req.originalUrl.slice(queryIndex) : "";
  return res.redirect(301, `${cleanPath}${query}`);
});
app.use("/uploads", express.static(uploadDir, {
  etag: true,
  maxAge: IS_PRODUCTION ? "1d" : 0
}));
app.use(express.static(path.join(__dirname, "public"), {
  etag: true,
  maxAge: IS_PRODUCTION ? "1h" : 0
}));

let submissions = [];
let content = null;
let adminAuth = null;
let members = [];
const ensureDataFile = async () => {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
    const content = await fs.readFile(DATA_FILE, "utf8");
    submissions = JSON.parse(content || "[]");
  } catch (err) {
    submissions = [];
    await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
  }
};

const ensureMembersFile = async () => {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
    const raw = await fs.readFile(MEMBERS_FILE, "utf8");
    members = JSON.parse(raw || "[]");
    if (!Array.isArray(members)) members = [];
  } catch (err) {
    members = [];
    await fs.writeFile(MEMBERS_FILE, JSON.stringify(members, null, 2));
  }
};

const defaultContent = {
  hours: {
    monSat: "05:00 PM - 09:00 AM",
    sunday: "Half day"
  },
  contact: {
    phone: "+25191 219 6096",
    email: "tenasgymandspa@gmail.com"
  },
  payment: {
    link: ""
  },
  membershipTiers: [
    { name: "Unlimited", price: "$7000/mo", desc: "Full access, all classes, recovery suite." },
    { name: "3x / Week", price: "$6000/mo", desc: "Strength + conditioning sessions with open gym." },
    { name: "Starter", price: "$5000/mo", desc: "Open gym + 1 class weekly." }
  ],
  membershipPerks: [
    "Movement screen + onboarding",
    "Coach feedback and program updates",
    "Recovery suite access",
    "Community events + challenges"
  ],
  priceList: {
    periods: ["1 Month", "2 Month", "3 Month", "6 Month", "1 Year"],
    columns: [
      "Full Package (Gym, Spa, Aerobics)",
      "Gym and Spa",
      "Gym and Aerobics",
      "Gym Only",
      "Aerobics Only",
      "Off Peak Hour"
    ],
    prices: [
      ["9,999", "7,999", "7,499", "5,999", "3,999", "4,999"],
      ["18,799", "14,999", "13,999", "11,099", "7,359", "9,139"],
      ["23,999", "19,679", "18,499", "14,399", "9,999", "12,209"],
      ["39,999", "32,639", "30,999", "26,199", "17,999", "22,199"],
      ["69,999", "57,599", "53,999", "43,599", "33,299", "38,999"]
    ]
  },
  dailyPass: [
    { label: "Daily pass F.P", price: "1,199" },
    { label: "Daily pass Gym", price: "499" },
    { label: "Daily pass Aerobics", price: "499" }
  ],
  discounts: [
    { label: "3 person", value: "5% each" },
    { label: ">= 4 person", value: "7% each" }
  ],
  referralCodes: [], 
  announcements: [],
  shopProducts: [
    {
      category: "Protein",
      name: "Whey Isolate",
      price: "ETB 8,500",
      desc: "Fast-digesting post-workout protein to support lean muscle recovery and daily intake.",
      tag: "Best Seller",
      img: ""
    },
    {
      category: "Creatine",
      name: "Creatine Monohydrate",
      price: "ETB 3,200",
      desc: "A simple strength staple for power output, performance, and steady progress.",
      tag: "Strength Essential",
      img: ""
    },
    {
      category: "Recovery",
      name: "BCAA + Electrolytes",
      price: "ETB 2,900",
      desc: "Hydration and recovery support for long sessions, hot days, and high-volume training.",
      tag: "Recovery Stack",
      img: ""
    },
    {
      category: "Energy",
      name: "Pre-Workout Blend",
      price: "ETB 4,400",
      desc: "A focus and energy boost before demanding sessions without needing to leave the gym.",
      tag: "Before Training",
      img: ""
    }
  ],
  priceNote: "The prices above do not include the ETB 500 membership card fee.",
  programs: [
    {
      name: "Strength Track",
      desc: "Barbell progressions with weekly performance tracking and coaching feedback.",
      focus: ["Squat/Bench/Deadlift", "Progressive overload", "Technique coaching"]
    },
    {
      name: "Hybrid Conditioning",
      desc: "Engine-building sessions that mix cardio, sled work, and functional strength.",
      focus: ["Intervals", "Sled work", "Athletic conditioning"]
    },
    {
      name: "Recovery Flow",
      desc: "Mobility classes, breathwork, and guided stretching for longevity.",
      focus: ["Mobility", "Breathing", "Post-session recovery"]
    },
    {
      name: "Athlete Performance",
      desc: "Power, speed, and agility for sport-specific results.",
      focus: ["Sprint mechanics", "Explosive power", "Change of direction"]
    }
  ],
  schedule: [
    { time: "06:00", name: "Strength Foundations" },
    { time: "12:15", name: "Hyrox Conditioning" },
    { time: "18:30", name: "Power + Mobility" }
  ],
  coaches: [
    {
      name: "Kidus Mulgeta",
      role: "Head Strength Coach",
      img: "/images/kidus%20mulgeta.png",
      bio: "10+ years coaching strength athletes and general population clients.",
      skills: ["CSCS", "Powerlifting", "Mobility"],
      exp: "Focus: Maximum strength, clean technique, injury-proof mechanics."
    },
    {
      name: "Abebe Tadesse",
      role: "Performance & Conditioning",
      img: "/images/kidus%20mulgeta.png",
      bio: "Hybrid endurance specialist with a focus on sustainable intensity.",
      skills: ["USAW", "HIIT", "Hyrox"],
      exp: "Focus: Engine building, athletic conditioning, interval systems."
    },
    {
      name: "Abel Tesfaye",
      role: "Mobility & Recovery",
      img: "/images/kidus%20mulgeta.png",
      bio: "Movement coach helping members improve range and reduce pain.",
      skills: ["FRC", "Stretch Therapy", "Recovery"],
      exp: "Focus: Mobility systems, tissue care, pre-hab and post-hab."
    }
  ],
  machines: [
    {
      name: "Apex Power Rack",
      desc: "Heavy-duty rack for squats, bench, and pull-ups.",
      img: "/images/apex.png",
      targets: "Quads, glutes, back",
      bestFor: "Compound strength",
      tip: "Brace your core before every rep."
    },
    {
      name: "Vector Cable Station",
      desc: "Dual-stack cables for full-range strength work.",
      img: "/images/victor-cable.png",
      targets: "Chest, shoulders, arms",
      bestFor: "Cables, flyes, rows",
      tip: "Keep constant tension."
    },
    {
      name: "Storm Air Bike",
      desc: "Assault-style bike with infinite resistance.",
      img: "/images/bike.png",
      targets: "Full body engine",
      bestFor: "Intervals, warm-ups",
      tip: "Push and pull together for max output."
    },
    {
      name: "Precision Leg Press",
      desc: "45-degree sled with smooth rails and oversized footplate.",
      img: "/images/leg press.png",
      targets: "Quads, glutes, calves",
      bestFor: "Strength & volume",
      tip: "Drive through mid-foot for control."
    },
    {
      name: "Crossover Fly Station",
      desc: "Adjustable fly station for chest and shoulder isolation.",
      img: "/images/cross.png",
      targets: "Chest, shoulders",
      bestFor: "Flyes, isolation",
      tip: "Keep elbows soft through the arc."
    },
    {
      name: "Functional Trainer Pro",
      desc: "Versatile cable unit for full-body training.",
      img: "/images/functional.png",
      targets: "Full body",
      bestFor: "Functional strength",
      tip: "Control the negative on every rep."
    },
    {
      name: "Power Rack Elite",
      desc: "Heavy rack for max strength and safe spotting.",
      img: "/images/power.png",
      targets: "Quads, glutes, back",
      bestFor: "Squats, presses",
      tip: "Set safety pins before lifting heavy."
    },
    {
      name: "Hydro Row Elite",
      desc: "Water-resistance rower with smooth glide.",
      img: "images/hydro.png",
      targets: "Back, legs, core",
      bestFor: "Cardio endurance",
      tip: "Drive with legs, finish with arms."
    },
    {
      name: "Glide Leg Press",
      desc: "45-degree sled with wide foot plate.",
      img: "/images/leg press.png",
      targets: "Quads, glutes, calves",
      bestFor: "Hypertrophy blocks",
      tip: "Control the descent for growth."
    },
    {
      name: "Pulse Sled Track",
      desc: "Turf lane for sled pushes and pulls.",
      img: "images/pulse-sled.png",
      targets: "Legs, lungs",
      bestFor: "Conditioning",
      tip: "Stay low and drive through the floor."
    }
  ]
};

const ensureContentFile = async () => {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
    const raw = await fs.readFile(CONTENT_FILE, "utf8");
    content = JSON.parse(raw || "{}");
  } catch (err) {
    content = defaultContent;
    await fs.writeFile(CONTENT_FILE, JSON.stringify(content, null, 2));
  }
};

const hashPassword = (password, salt) => {
  const actualSalt = salt || crypto.randomBytes(16).toString("hex");
  const hash = crypto.pbkdf2Sync(password, actualSalt, 310000, 32, "sha256").toString("hex");
  return { salt: actualSalt, hash };
};

const verifyPassword = (password, auth) => {
  if (!password || !auth?.salt || !auth?.hash) return false;
  const hash = crypto.pbkdf2Sync(password, auth.salt, 310000, 32, "sha256").toString("hex");
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(auth.hash, "hex"));
};

const signAdminToken = () => {
  const payload = Buffer.from(JSON.stringify({
    type: "admin",
    issuedAt: Date.now(),
    authVersion: adminAuth?.updatedAt || ""
  })).toString("base64url");
  const signature = crypto
    .createHmac("sha256", OTP_SECRET)
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
};

const verifyAdminToken = (token) => {
  if (!token || revokedAdminTokens.has(token)) return false;
  const [payload, signature, extra] = String(token).split(".");
  if (!payload || !signature || extra) return false;

  const expected = crypto
    .createHmac("sha256", OTP_SECRET)
    .update(payload)
    .digest();
  let actual;
  try {
    actual = Buffer.from(signature, "base64url");
  } catch {
    return false;
  }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) {
    return false;
  }

  try {
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return parsed.type === "admin"
      && parsed.authVersion === (adminAuth?.updatedAt || "")
      && Number.isFinite(parsed.issuedAt)
      && parsed.issuedAt <= Date.now()
      && Date.now() - parsed.issuedAt <= ADMIN_TOKEN_TTL_MS;
  } catch {
    return false;
  }
};

const saveAdminAuth = async (password) => {
  const { salt, hash } = hashPassword(password);
  adminAuth = { salt, hash, updatedAt: new Date().toISOString() };
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(ADMIN_CONFIG_FILE, JSON.stringify(adminAuth, null, 2));
};

const ensureAdminFile = async () => {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
    const raw = await fs.readFile(ADMIN_CONFIG_FILE, "utf8");
    adminAuth = JSON.parse(raw || "{}");
    if (!adminAuth?.salt || !adminAuth?.hash) {
      await saveAdminAuth(ADMIN_PASSWORD);
    }
  } catch (err) {
    await saveAdminAuth(ADMIN_PASSWORD);
  }
};

const normalizeEmail = (value) => String(value || "").trim().toLowerCase();
const normalizeLooseText = (value) => String(value || "").trim().toLowerCase().replace(/\s+/g, " ");
const normalizePhone = (value) => String(value || "").replace(/[^\d+]/g, "");
const getAdminEmail = () => normalizeEmail(ADMIN_EMAIL || content?.contact?.email || "info@tenasgym.com");

const getMailer = () => {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || 587);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const secure = String(process.env.SMTP_SECURE || "").toLowerCase() === "true" || port === 465;
  if (!host || !user || !pass) return null;
  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass }
  });
};

const createOtp = (email) => {
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const hash = crypto.createHash("sha256").update(code + OTP_SECRET).digest("hex");
  otpStore.set(email, {
    hash,
    expiresAt: Date.now() + OTP_TTL_MS,
    attempts: 0,
    lastSentAt: Date.now()
  });
  return code;
};

const verifyOtp = (email, code) => {
  const entry = otpStore.get(email);
  if (!entry) return false;
  if (Date.now() > entry.expiresAt) {
    otpStore.delete(email);
    return false;
  }
  if (entry.attempts >= 6) {
    otpStore.delete(email);
    return false;
  }
  const hash = crypto.createHash("sha256").update(String(code || "") + OTP_SECRET).digest("hex");
  const ok = crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(entry.hash, "hex"));
  if (!ok) {
    entry.attempts += 1;
    return false;
  }
  otpStore.delete(email);
  return true;
};

const sendOtpEmail = async (email, code) => {
  const transporter = getMailer();
  if (!transporter) {
    throw new Error("Email not configured");
  }
  const from = process.env.SMTP_FROM || process.env.SMTP_USER || "no-reply@tenasgym.com";
  const subject = "Tenas Admin Password Reset Code";
  const text = `Your password reset code is: ${code}\nThis code expires in 10 minutes.`;
  await transporter.sendMail({ from, to: email, subject, text });
};

const hasTelegramConfig = () => Boolean(TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID);
const saveSubmission = async (entry) => {
  submissions.unshift(entry);
  await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
};

const saveMembers = async () => {
  await fs.writeFile(MEMBERS_FILE, JSON.stringify(members, null, 2));
};

const getMemberPublic = (member) => {
  if (!member) return null;
  return {
    id: member.id,
    email: member.email,
    fullName: member.fullName || "",
    phone: member.phone || "",
    membership: member.membership || null,
    createdAt: member.createdAt || null
  };
};

const syncMemberMembershipFromSubmission = (member, submission) => {
  if (!member || !submission || submission.type !== "membership") return;
  member.fullName = submission.fullName || member.fullName || "";
  member.phone = submission.phone || member.phone || "";
  member.membership = {
    submissionId: submission.id,
    fullName: submission.fullName || member.fullName || "",
    email: submission.email || member.email,
    phone: submission.phone || member.phone || "",
    plan: submission.plan || "",
    membershipType: submission.membershipType || "",
    startDate: submission.startDate || "",
    paymentMethod: submission.paymentMethod || "",
    paymentReference: submission.paymentReference || "",
    referralCode: submission.referralCode || "",
    referralPercent: Number(submission.referralDiscountPercent || 0) || 0,
    calculatedPrice: submission.calculatedPrice || "",
    status: submission.status || "pending",
    notes: submission.notes || "",
    createdAt: submission.createdAt || new Date().toISOString()
  };
};

const matchesMemberSubmission = (member, submission) => {
  if (!member || !submission) return false;
  if (submission.memberId) return submission.memberId === member.id;

  const submissionEmail = normalizeEmail(submission.email);
  return Boolean(submissionEmail && submissionEmail === member.email);
};

const isActiveUntil = (value) => {
  if (!value) return true;
  const normalized = String(value).trim();
  const parsed = new Date(normalized.length <= 10 ? `${normalized}T23:59:59` : normalized);
  if (Number.isNaN(parsed.getTime())) return true;
  return parsed.getTime() >= Date.now();
};

const requireMember = (req, res, next) => {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  const memberId = token ? memberTokens.get(token) : "";
  const member = memberId ? members.find((item) => item.id === memberId) : null;
  if (!token || !member) {
    return res.status(401).json({ ok: false, error: "Unauthorized" });
  }
  req.member = member;
  req.memberToken = token;
  return next();
};

const requireAdmin = (req, res, next) => {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!verifyAdminToken(token)) {
    return res.status(401).json({ ok: false, error: "Unauthorized" });
  }
  req.adminToken = token;
  return next();
};

app.get("/coaches", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "coaches.html"));
});

app.get("/gallery", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "gallery.html"));
});

app.get("/shop", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "shop.html"));
});

app.get("/machines", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "machines.html"));
});

app.get(["/programs", "/programs.html"], (req, res) => {
  res.redirect(302, "/");
});

app.get("/spa", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "spa.html"));
});

app.get("/membership", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "membership.html"));
});

app.get("/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "dashboard.html"));
});

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "tenas-gym",
    timestamp: new Date().toISOString()
  });
});

app.get("/tour", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "tour.html"));
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});
app.post("/api/tour", async (req, res) => {
  try {
    const { fullName, phone } = req.body || {};
    if (!fullName || !phone) {
      return res.status(400).json({ ok: false, error: "Missing full name or phone" });
    }
    if (hasTelegramConfig()) {
      const message = "New tour request\nName: " + fullName + "\nPhone: " + phone + "\nTime: " + new Date().toISOString();
      const url = "https://api.telegram.org/bot" + TELEGRAM_BOT_TOKEN + "/sendMessage";
      const tgRes = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: message })
      });
      if (!tgRes.ok) {
        const errText = await tgRes.text();
        return res.status(502).json({ ok: false, error: errText });
      }
    }
    await saveSubmission({
      id: crypto.randomUUID(),
      type: "tour",
      fullName,
      phone,
      createdAt: new Date().toISOString()
    });
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err) });
  }
});

app.post("/api/shop-order", async (req, res) => {
  try {
    const payload = req.body || {};
    const fullName = String(payload.fullName || "").trim();
    const phone = String(payload.phone || "").trim();
    const notes = String(payload.notes || "").trim();
    const items = Array.isArray(payload.items) ? payload.items.filter((item) => item?.name) : [];

    if (!fullName || !phone) {
      return res.status(400).json({ ok: false, error: "Missing full name or phone" });
    }
    if (!items.length) {
      return res.status(400).json({ ok: false, error: "Please select at least one item" });
    }

    const itemLines = items.map((item) => {
      const qty = Math.max(1, Number(item.quantity) || 1);
      return `${item.name} x${qty}${item.price ? ` (${item.price})` : ""}`;
    });

    if (hasTelegramConfig()) {
      const message = [
        "New shop order",
        "Name: " + fullName,
        "Phone: " + phone,
        "Items:",
        ...itemLines.map((line) => "- " + line),
        "Notes: " + (notes || "N/A"),
        "Submitted: " + new Date().toISOString()
      ].join("\n");

      const url = "https://api.telegram.org/bot" + TELEGRAM_BOT_TOKEN + "/sendMessage";
      const tgRes = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: message })
      });
      if (!tgRes.ok) {
        const errText = await tgRes.text();
        return res.status(502).json({ ok: false, error: errText });
      }
    }

    await saveSubmission({
      id: crypto.randomUUID(),
      type: "shop",
      fullName,
      phone,
      items,
      notes,
      createdAt: new Date().toISOString()
    });
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err) });
  }
});

app.post("/api/member/signup", async (req, res) => {
  try {
    const email = normalizeEmail(req.body?.email);
    const password = String(req.body?.password || "");
    const fullName = String(req.body?.fullName || "").trim();
    const phone = String(req.body?.phone || "").trim();
    if (!email || !password || !fullName) {
      return res.status(400).json({ ok: false, error: "Full name, email, and password are required" });
    }
    if (password.length < 6) {
      return res.status(400).json({ ok: false, error: "Password must be at least 6 characters" });
    }
    if (members.some((item) => item.email === email)) {
      return res.status(409).json({ ok: false, error: "An account already exists for this email" });
    }
    const passwordAuth = hashPassword(password);
    const member = {
      id: crypto.randomUUID(),
      email,
      fullName,
      phone,
      passwordSalt: passwordAuth.salt,
      passwordHash: passwordAuth.hash,
      membership: null,
      createdAt: new Date().toISOString()
    };
    const previousMembership = submissions.find((item) => item.type === "membership" && normalizeEmail(item.email) === email);
    if (previousMembership) {
      previousMembership.memberId = member.id;
      syncMemberMembershipFromSubmission(member, previousMembership);
      await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
    }
    members.unshift(member);
    await saveMembers();
    const token = crypto.randomBytes(24).toString("hex");
    memberTokens.set(token, member.id);
    return res.json({ ok: true, token, member: getMemberPublic(member) });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err) });
  }
});

app.post("/api/member/login", async (req, res) => {
  try {
    const email = normalizeEmail(req.body?.email);
    const password = String(req.body?.password || "");
    const member = members.find((item) => item.email === email);
    const auth = member ? { salt: member.passwordSalt, hash: member.passwordHash } : null;
    if (!member || !verifyPassword(password, auth)) {
      return res.status(401).json({ ok: false, error: "Invalid email or password" });
    }
    if (!member.membership) {
      const previousMembership = submissions.find((item) => item.type === "membership" && normalizeEmail(item.email) === email);
      if (previousMembership) {
        previousMembership.memberId = member.id;
        syncMemberMembershipFromSubmission(member, previousMembership);
        await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
        await saveMembers();
      }
    }
    const token = crypto.randomBytes(24).toString("hex");
    memberTokens.set(token, member.id);
    return res.json({ ok: true, token, member: getMemberPublic(member) });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err) });
  }
});

app.post("/api/member/logout", requireMember, (req, res) => {
  memberTokens.delete(req.memberToken);
  return res.json({ ok: true });
});

app.get("/api/member/me", requireMember, async (req, res) => {
  const latestMembership = submissions.find((item) => item.type === "membership" && (item.memberId === req.member.id || normalizeEmail(item.email) === req.member.email));
  if (latestMembership) {
    latestMembership.memberId = req.member.id;
    syncMemberMembershipFromSubmission(req.member, latestMembership);
    await saveMembers();
    await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
  }
  return res.json({ ok: true, member: getMemberPublic(req.member) });
});

app.get("/api/member/dashboard", requireMember, async (req, res) => {
  const latestMembership = submissions.find((item) => item.type === "membership" && matchesMemberSubmission(req.member, item));
  if (latestMembership) {
    latestMembership.memberId = req.member.id;
    syncMemberMembershipFromSubmission(req.member, latestMembership);
    await saveMembers();
    await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
  }

  const shopOrders = submissions
    .filter((item) => item.type === "shop" && matchesMemberSubmission(req.member, item))
    .slice(0, 6)
    .map((item) => ({
      id: item.id,
      fullName: item.fullName || "",
      phone: item.phone || "",
      status: item.status || "Received",
      notes: item.notes || "",
      items: Array.isArray(item.items) ? item.items : [],
      createdAt: item.createdAt || null
    }));

  const tourRequests = submissions
    .filter((item) => item.type === "tour" && matchesMemberSubmission(req.member, item))
    .slice(0, 6)
    .map((item) => ({
      id: item.id,
      fullName: item.fullName || "",
      phone: item.phone || "",
      status: item.status || "Requested",
      notes: item.notes || "",
      createdAt: item.createdAt || null
    }));

  const memberAnnouncements = Array.isArray(content?.announcements)
    ? content.announcements
        .filter((item) => isActiveUntil(item?.expiresAt))
        .slice(0, 4)
        .map((item) => ({
          id: item.id || crypto.randomUUID(),
          tag: item.tag || "Update",
          title: item.title || "",
          text: item.text || "",
          dateLabel: item.dateLabel || "",
          link: item.link || ""
        }))
    : [];

  const recentActivity = [
    ...(req.member.membership
      ? [{
          id: `membership-${req.member.membership.submissionId || req.member.id}`,
          type: "membership",
          title: req.member.membership.plan
            ? `Membership saved for ${req.member.membership.plan}`
            : "Membership saved",
          status: req.member.membership.status || "Pending Approval",
          createdAt: req.member.membership.createdAt || req.member.createdAt || null
        }]
      : []),
    ...shopOrders.map((item) => ({
      id: `shop-${item.id}`,
      type: "shop",
      title: `Shop order with ${item.items.length} item${item.items.length === 1 ? "" : "s"}`,
      status: item.status,
      createdAt: item.createdAt
    })),
    ...tourRequests.map((item) => ({
      id: `tour-${item.id}`,
      type: "tour",
      title: "Tour request submitted",
      status: item.status,
      createdAt: item.createdAt
    }))
  ]
    .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
    .slice(0, 8);

  return res.json({
    ok: true,
    member: getMemberPublic(req.member),
    membership: req.member.membership || null,
    shopOrders,
    tourRequests,
    recentActivity,
    announcements: memberAnnouncements,
    contact: content?.contact || {}
  });
});

app.patch("/api/member/profile", requireMember, async (req, res) => {
  const fullName = String(req.body?.fullName || "").trim();
  const phone = String(req.body?.phone || "").trim();
  if (!fullName) {
    return res.status(400).json({ ok: false, error: "Full name is required" });
  }
  req.member.fullName = fullName;
  req.member.phone = phone;
  if (req.member.membership) {
    req.member.membership.fullName = fullName;
    req.member.membership.phone = phone;
  }
  await saveMembers();
  return res.json({ ok: true, member: getMemberPublic(req.member) });
});

app.post("/api/admin/login", (req, res) => {
  const { password } = req.body || {};
  if (!verifyPassword(password, adminAuth)) {
    return res.status(401).json({ ok: false, error: "Invalid password" });
  }
  const token = signAdminToken();
  return res.json({ ok: true, token });
});

app.post("/api/admin/password", requireAdmin, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!verifyPassword(currentPassword, adminAuth)) {
    return res.status(401).json({ ok: false, error: "Invalid current password" });
  }
  if (!newPassword || String(newPassword).length < 8) {
    return res.status(400).json({ ok: false, error: "New password must be at least 8 characters" });
  }
  await saveAdminAuth(String(newPassword));
  return res.json({ ok: true });
});

app.post("/api/admin/forgot", async (req, res) => {
  const { email } = req.body || {};
  const normalized = normalizeEmail(email);
  if (!normalized) {
    return res.status(400).json({ ok: false, error: "Email is required" });
  }
  const adminEmail = getAdminEmail();
  if (normalized !== adminEmail) {
    return res.json({ ok: true });
  }
  const existing = otpStore.get(normalized);
  if (existing && Date.now() - existing.lastSentAt < OTP_COOLDOWN_MS) {
    return res.status(429).json({ ok: false, error: "Please wait before requesting another code" });
  }
  try {
    const code = createOtp(normalized);
    await sendOtpEmail(normalized, code);
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err) });
  }
});

app.post("/api/admin/reset", async (req, res) => {
  const { email, otp, newPassword } = req.body || {};
  const normalized = normalizeEmail(email);
  const adminEmail = getAdminEmail();
  if (!normalized || normalized !== adminEmail) {
    return res.status(400).json({ ok: false, error: "Invalid request" });
  }
  if (!otp) {
    return res.status(400).json({ ok: false, error: "OTP is required" });
  }
  if (!newPassword || String(newPassword).length < 8) {
    return res.status(400).json({ ok: false, error: "New password must be at least 8 characters" });
  }
  if (!verifyOtp(normalized, otp)) {
    return res.status(401).json({ ok: false, error: "Invalid or expired OTP" });
  }
  await saveAdminAuth(String(newPassword));
  return res.json({ ok: true });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  if (req.adminToken) revokedAdminTokens.add(req.adminToken);
  return res.json({ ok: true });
});

app.get("/api/admin/stats", requireAdmin, (req, res) => {
  const total = submissions.length;
  const membership = submissions.filter((item) => item.type === "membership").length;
  const tour = submissions.filter((item) => item.type === "tour").length;
  const last = submissions[0]?.createdAt || null;
  return res.json({ ok: true, total, membership, tour, last });
});

app.get("/api/admin/submissions", requireAdmin, (req, res) => {
  return res.json({ ok: true, submissions });
});

app.post("/api/admin/upload", requireAdmin, uploadImage.single("image"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ ok: false, error: "No file uploaded" });
  }
  const urlPath = `/uploads/${req.file.filename}`;
  return res.json({ ok: true, path: urlPath });
});

app.patch("/api/admin/submissions/:id", requireAdmin, async (req, res) => {
  const { id } = req.params;
  const updates = req.body || {};
  const idx = submissions.findIndex((item) => item.id === id);
  if (idx === -1) {
    return res.status(404).json({ ok: false, error: "Not found" });
  }
  submissions[idx] = {
    ...submissions[idx],
    status: updates.status ?? submissions[idx].status ?? "new",
    notes: updates.notes ?? submissions[idx].notes ?? ""
  };
  if (submissions[idx].type === "membership" && submissions[idx].memberId) {
    const member = members.find((item) => item.id === submissions[idx].memberId);
    if (member) {
      syncMemberMembershipFromSubmission(member, submissions[idx]);
      await saveMembers();
    }
  }
  await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
  return res.json({ ok: true, submission: submissions[idx] });
});

app.delete("/api/admin/submissions/:id", requireAdmin, async (req, res) => {
  const { id } = req.params;
  const next = submissions.filter((item) => item.id !== id);
  if (next.length === submissions.length) {
    return res.status(404).json({ ok: false, error: "Not found" });
  }
  submissions = next;
  await fs.writeFile(DATA_FILE, JSON.stringify(submissions, null, 2));
  return res.json({ ok: true });
});

app.get("/api/admin/content", requireAdmin, (req, res) => {
  return res.json({ ok: true, content });
});

app.put("/api/admin/content", requireAdmin, async (req, res) => {
  try {
    const payload = req.body || {};
    content = payload;
    await fs.writeFile(CONTENT_FILE, JSON.stringify(content, null, 2));
    await fs.writeFile(PUBLIC_CONTENT_FILE, JSON.stringify(content, null, 2));
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err) });
  }
});

app.get("/api/content", (req, res) => {
  return res.json({ ok: true, content });
});

app.get("/api/stats", (req, res) => {
  const total = submissions.length;
  const membership = submissions.filter((item) => item.type === "membership").length;
  const tour = submissions.filter((item) => item.type === "tour").length;
  const last = submissions[0]?.createdAt || null;
  return res.json({ ok: true, total, membership, tour, last });
});

app.post(
  "/api/membership",
  upload.fields([
    { name: "profilePhoto", maxCount: 1 },
    { name: "paymentProof", maxCount: 1 }
  ]),
  async (req, res) => {
  try {
    const payload = req.body || {};
    const auth = req.headers.authorization || "";
    const memberToken = auth.startsWith("Bearer ") ? auth.slice(7) : "";
    const memberId = memberToken ? memberTokens.get(memberToken) : "";
    const member = memberId ? members.find((item) => item.id === memberId) : null;
    const normalizedEmail = normalizeEmail(payload.email);
    if (member) {
      if (member.email !== normalizedEmail) {
        return res.status(400).json({ ok: false, error: "Please use the same email as your member account" });
      }
      member.fullName = payload.fullName || member.fullName || "";
      member.phone = payload.phone || member.phone || "";
    }
    const required = ["fullName", "phone", "email", "plan", "membershipType", "startDate", "paymentMethod"];
    for (const field of required) {
      if (!payload[field]) {
        return res.status(400).json({ ok: false, error: "Missing required field: " + field });
      }
    }
    const profilePhoto = req.files?.profilePhoto?.[0];
    const paymentProof = req.files?.paymentProof?.[0];
    if (!profilePhoto) {
      return res.status(400).json({ ok: false, error: "Missing required field: profilePhoto" });
    }

    const goalsArr = Array.isArray(payload.goals) ? payload.goals : payload.goals ? [payload.goals] : [];
    const conditionsArr = Array.isArray(payload.conditions) ? payload.conditions : payload.conditions ? [payload.conditions] : [];
    const goals = goalsArr.length ? goalsArr.join(", ") : "None";
    const conditions = conditionsArr.length ? conditionsArr.join(", ") : "None";

    const messageLines = [
      "New membership request",
      "Name: " + payload.fullName,
      "Phone: " + payload.phone,
      "Email: " + payload.email,
      "DOB: " + (payload.dob || "N/A"),
      "Gender: " + (payload.gender || "N/A"),
      "Emergency Contact: " + (payload.emergencyContact || "N/A"),
      "Emergency Phone: " + (payload.emergencyPhone || "N/A"),
      "Plan: " + payload.plan,
      "Membership Type: " + payload.membershipType,
      "Start Date: " + payload.startDate,
      "Preferred Time: " + (payload.preferredTime || "N/A"),
      "Training: " + (payload.training || "N/A"),
      "Goals: " + goals,
      "Medical Conditions: " + (payload.medicalConditions || "N/A"),
      "Medical Details: " + (payload.medicalDetails || "N/A"),
      "Medications: " + (payload.medications || "N/A"),
      "Medication Details: " + (payload.medicationDetails || "N/A"),
      "Past Conditions: " + conditions,
      "Doctor Advised Against Exercise: " + (payload.doctorAdvised || "N/A"),
      "Payment Method: " + payload.paymentMethod,
      "Payment Reference: " + (payload.paymentReference || "N/A"),
      "Referral Code: " + (payload.referralCode || "N/A"),
      "Referral Discount: " + (payload.referralDiscountPercent ? payload.referralDiscountPercent + "%" : "N/A"),
      "Calculated Price: " + (payload.calculatedPrice || "N/A"),
      "Submitted: " + new Date().toISOString()
    ];

    if (hasTelegramConfig()) {
      const message = messageLines.join("\n");
      const messageUrl = "https://api.telegram.org/bot" + TELEGRAM_BOT_TOKEN + "/sendMessage";
      const tgRes = await fetch(messageUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: message })
      });
      if (!tgRes.ok) {
        const errText = await tgRes.text();
        return res.status(502).json({ ok: false, error: errText });
      }

      const sendPhotoToTelegram = async (photo) => {
        const form = new FormData();
        form.append("chat_id", TELEGRAM_CHAT_ID);
        if (typeof Blob !== "undefined") {
          form.append("photo", new Blob([photo.buffer], { type: photo.mimetype }), photo.originalname || "upload");
        } else {
          form.append("photo", photo.buffer, photo.originalname || "upload");
        }
        const photoUrl = "https://api.telegram.org/bot" + TELEGRAM_BOT_TOKEN + "/sendPhoto";
        const photoRes = await fetch(photoUrl, { method: "POST", body: form });
        if (!photoRes.ok) {
          const errText = await photoRes.text();
          throw new Error(errText);
        }
      };

      await sendPhotoToTelegram(profilePhoto);

      if (paymentProof) {
        await sendPhotoToTelegram(paymentProof);
      }
    }

    const submission = {
      id: crypto.randomUUID(),
      type: "membership",
      memberId: member?.id || "",
      fullName: payload.fullName,
      phone: payload.phone,
      email: payload.email,
      plan: payload.plan,
      membershipType: payload.membershipType,
      startDate: payload.startDate,
      preferredTime: payload.preferredTime || "",
      training: payload.training || "",
      goals: goalsArr,
      paymentMethod: payload.paymentMethod,
      paymentReference: payload.paymentReference || "",
      referralCode: payload.referralCode || "",
      referralDiscountPercent: payload.referralDiscountPercent || "",
      calculatedPrice: payload.calculatedPrice || "",
      status: "pending",
      notes: "",
      createdAt: new Date().toISOString()
    };
    await saveSubmission(submission);
    if (member) {
      syncMemberMembershipFromSubmission(member, submission);
      await saveMembers();
    }
    return res.json({ ok: true, membership: member ? member.membership : null });
  } catch (err) {
    return res.status(500).json({ ok: false, error: String(err) });
  }
});

app.use((err, req, res, next) => {
  if (!err) return next();
  if (req.path.startsWith("/api/")) {
    const message = err.code === "LIMIT_FILE_SIZE"
      ? "Uploaded image is too large. Maximum size is 6MB."
      : err.message || "Upload failed";
    return res.status(400).json({ ok: false, error: message });
  }
  return next(err);
});

app.use("/api", (req, res) => {
  return res.status(404).json({ ok: false, error: "API route not found" });
});

app.use((req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const start = async () => {
  if (IS_PRODUCTION) {
    const required = ["ADMIN_PASSWORD", "ADMIN_EMAIL", "OTP_SECRET"];
    const missing = required.filter((key) => !String(process.env[key] || "").trim());
    if (missing.length) {
      throw new Error(`Missing required production environment variables: ${missing.join(", ")}`);
    }
    if (String(process.env.ADMIN_PASSWORD).length < 12) {
      throw new Error("ADMIN_PASSWORD must contain at least 12 characters in production");
    }
    if (String(process.env.OTP_SECRET).length < 32) {
      throw new Error("OTP_SECRET must contain at least 32 characters in production");
    }
  }
  await ensureDataFile();
  await ensureMembersFile();
  await ensureContentFile();
  await ensureAdminFile();
  await fs.mkdir(uploadDir, { recursive: true });
  app.listen(PORT, () => {
    console.log(`Tenas Gym and Spa running on http://localhost:${PORT}`);
  });
};

start().catch((err) => {
  console.error("Tenas Gym failed to start", err);
  process.exitCode = 1;
});
